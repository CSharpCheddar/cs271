/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author krohne
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyArrayList myList = new MyArrayList();
        MyCircle test = new MyCircle(10);
        myList.insert(new MyCircle(20));
        myList.insert(new MyCircle(15));
        myList.insert(new MyCircle(25));
        myList.insert(test);
        System.out.println("Should be true: "+myList.contains(test));
        System.out.println("Should be false: "+myList.contains(new MyCircle(10)));
        myList.print();  //print out all circles
    }
    
}
